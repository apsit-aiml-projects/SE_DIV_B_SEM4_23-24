<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <style>
        #ques{
            min-height: 433px;
        }
    </style>
    <title>Welcome to Interact</title>
</head>

<body>
    <?php include 'partials/_dbconnect.php';?>
    <?php include 'partials/_header.php';?>
    <?php
    
    $id= $_GET['catid'];
    $sql = "SELECT* FROM `categories` WHERE category_id=$id ";
    $result= mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)){
       $catname = $row['category_name'];
       $catdesc = $row['category_description'];
    }
    ?>
    <?php 
    $showAlert= false;
    $method = $_SERVER['REQUEST_METHOD'];
    if ($method == 'POST') {
      // Check if both title and description are not empty
      if (empty($_POST['title']) || empty($_POST['desc'])) {
          // Display an error message
          echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                      <strong>Error!</strong> Title and description cannot be empty!
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                </div>';
      } else {
          // Insert thread into db
          $th_title = $_POST['title'];
          $th_desc = $_POST['desc'];
          $sno = isset($_SESSION['sno']) ? $_SESSION['sno'] : null;
          $sql = "INSERT INTO `thread` ( `thread_title`, `thread_desc`, `thread_cat_id`, `thread_user_id`, `timestamp`) VALUES ( '$th_title', '$th_desc', '$id', '$sno', current_timestamp())";
          $result = mysqli_query($conn, $sql);
          $showAlert = true;
          if ($showAlert) {
              echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong>Success!</strong> Your question has been posted please wait for others to respond.
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>';
          }
      }
  }
    
    ?>
    
<div class="container my-4" >
<div class="jumbotron">
  <h1 class="display-4">Welcome to <?php echo $catname ;?></h1>
  <p class="lead"></p>
  <hr class="my-4">
  <p><?php echo $catdesc?></p>
  <p class="lead">
    <a class="btn btn-warning btn-lg" href="#" role="button">Learn more</a>
  </p>
</div>
</div>
<?php
if(isset($_SESSION['loggedin']) && $_SESSION['loggedin']==true){
 echo '<div class="container">
<h1 class="py-2">Ask a question</h1>
 <form action="'. $_SERVER["REQUEST_URI"].'" method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Q. Title</label>
    <input type="text" class="form-control" id="title" name="title" aria-describedby="emailHelp" placeholder="Enter your question">
    <small id="title" class="form-text text-muted">Keep your title as short as possible</small>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">Elaborate your concern</label>
    <textarea class="form-control" id="desc" name="desc"rows="3"></textarea>
  </div>
  <button type="submit" class="btn btn-warning">Submit</button>
</form>
</div>';
}
else{
 echo'<div class="alert alert-warning" role="alert">
 Please login to comment <a href="index.php" class="alert-link">Login</a>. 
</div>';
}
?> 
 <div class="container" id="ques">
    <h1 class="py-2">Discussion</h1>
    <?php
    $id= $_GET['catid'];
    $sql = "SELECT* FROM `thread` WHERE thread_cat_id=$id ";
    $result= mysqli_query($conn,$sql);
    $noResult = true;
    while($row = mysqli_fetch_assoc($result)){
        $noResult= false;
       $id = $row['thread_id'];
       $title = $row['thread_title'];
       $desc = $row['thread_desc'];
       $threadtime =$row['timestamp'];
       $thread_user_id = $row['thread_user_id'];
       $sql2="SELECT username FROM `users` WHERE sno ='$thread_user_id'";
       $result2= mysqli_query($conn,$sql2);
       $row2 =mysqli_fetch_assoc($result2);

       
       
      
    
   
    echo '<div class="media">
  <img class="mr-3" src="images/userd.jpg" width=35px alt="">
  <div class="media-body">
  <p>'.$row2['username'] .' at '.$threadtime.'</p>

    <h5 class="mt-0"><a class="text-dark" href= "thread.php?threadid='.$id.'">'.$title.'</a></h5>
   '.$desc.'
  </div>
</div>
 ';
}
if($noResult){
    echo '<div class="jumbotron jumbotron-fluid">
    <div class="container">
      <h1 class="display-4">No results found</h1>
      <p class="lead"><b> Be the first person to ask a question</b></p>
    </div>
  </div>';
}

 ?>
 </div>
  
    <?php include 'partials/_footer.php';?>
  
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"
        integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous">
    </script>
</body>

</html>