<?php
$year = date("Y");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      padding: 0;
      height: 100vh; /* Make sure the body takes at least the full height of the viewport */
    }

    .footer {
      position: fixed;
      bottom: 0;
      width: 100%;
      background-color: #333; /* Choose your desired background color */
      color: #fff; /* Choose your desired text color */
      text-align: center;
      padding: 10px 0; /* Adjust the padding as needed */
    }
  </style>
</head>
<body>
  <!-- Your page content goes here -->

  <div class="container-fluid bg-dark text-light mb-0 mt-1000">
    <p class="text-center"> Copyright <?php echo $year ?> || All rights reserved</p>
  </div>

  <!-- Your page content ends here -->
</body>
</html>