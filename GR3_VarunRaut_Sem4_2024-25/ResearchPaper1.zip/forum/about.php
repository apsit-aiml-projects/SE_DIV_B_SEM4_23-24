<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interact - About Us</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }
        body {
            background-color: #f2f2f2;
        }
        .heading {
            width: 90%;
            margin: 20px auto;
            text-align: center;
        }
        .heading h1 {
            font-size: 50px;
            color: black;
            margin-bottom: 25px;
        }
        .container {
            width: 90%;
            margin: 0 auto;
        }
        .about {
            display: flex;
            align-items: center;
            justify-content: space-around;
            margin-top: 50px;
        }
        .about-image img {
            width: 350px;
            height: 300px;
        }
        .about-content {
            max-width: 60%;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .about-content ul {
            list-style-type: none;
            padding: 0;
        }
        .about-content li {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 15px;
            position: relative;
            padding-left: 20px; /* Add padding to create space for arrow */
        }
        .about-content li::before {
            content: "➤"; /* Use Unicode character for arrow */
            color: orange; /* Set arrow color to orange */
            font-weight: bold;
            font-size: 18px;
            position: absolute;
            left: 0;
            top: 1px;
        }
    </style>
</head>
<body>
<div class="heading">
    <h1>About Us</h1>
    <p>We are students of AP Shah Institute of Technology working on this website as our project for our Second Year academics.</p>
</div>  
<div class="container">
    <section class="about">
        <div class="about-image">
            <img src="images/logo-color.png" alt="Logo">
        </div>
        <div class="about-content">
            <ul>
                <li>The objective of creating this website is to provide a platform for like-minded people to engage in discussions.</li>
                <li>Unlike other discussion forums, here you can freely discuss topics without external interference.</li>
                <li>Your identity will be kept private, so you don't have to worry about your questions or comments.</li>
                <li>
                    For creating communities mail us at singhanup1508@gmail.com
                </li>
            </ul>
        </div>
    </section>
</div>  
</body>
</html>

