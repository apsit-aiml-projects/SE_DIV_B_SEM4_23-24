from flask import Flask, render_template, request
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import MinMaxScaler
import numpy as np

app = Flask(__name__)

# Load your dataset
restaurant = pd.read_csv("final.csv", encoding="latin1")

def convert_to_numeric(value):
    try:
        return float(value.replace(',', ''))
    except ValueError:
        return np.nan

def recommend_restaurants(user_address, user_cuisine, top_n=10):
    filtered_restaurants = restaurant[(restaurant['LOCATION'] == user_address) & (restaurant['CUISINE'] == user_cuisine)]

    recommendations = []

    if not filtered_restaurants.empty:
        filtered_restaurants['RATES'] = filtered_restaurants['RATES'].apply(convert_to_numeric)
        filtered_restaurants['RATES'].fillna(0, inplace=True)

        tfidf_vectorizer = TfidfVectorizer()
        tfidf_matrix = tfidf_vectorizer.fit_transform(filtered_restaurants['NAME'] + ' ' + filtered_restaurants['CUISINE'])

        numerical_features = filtered_restaurants[['RATES', 'COST']].values

        scaler = MinMaxScaler()
        numerical_features_scaled = scaler.fit_transform(numerical_features)

        combined_features = pd.DataFrame(tfidf_matrix.toarray(), columns=tfidf_vectorizer.get_feature_names_out())
        combined_features[['RATES', 'COST']] = numerical_features_scaled

        cosine_sim = cosine_similarity(combined_features)

        sorted_similar_restaurants = sorted(enumerate(cosine_sim[0]), key=lambda x: x[1], reverse=True)

        for i in range(1, min(top_n + 1, len(sorted_similar_restaurants))):
            index = sorted_similar_restaurants[i][0]
            recommendation = {
                'name': filtered_restaurants['NAME'].iloc[index],
                'cuisine': filtered_restaurants['CUISINE'].iloc[index],
                'rating': filtered_restaurants['RATES'].iloc[index],
                'cost': filtered_restaurants['COST'].iloc[index]
            }
            recommendations.append(recommendation)
    else:
        print(f"No restaurants found in the specified area ({user_address}) with the preferred cuisine ({user_cuisine}).")

    return recommendations

@app.route('/')
def index():
    return render_template('index.html', recommendations=None)

@app.route('/recommend', methods=['POST'])
def recommend():
    user_address = request.form['address']
    user_cuisine = request.form['cuisine']
    recommendations = recommend_restaurants(user_address, user_cuisine)
    return render_template('index.html', recommendations=recommendations)

if __name__ == '__main__':
    app.run(debug=True, port=5505)
