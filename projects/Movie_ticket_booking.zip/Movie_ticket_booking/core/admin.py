from django.contrib import admin
from .models import Movie, Showtime

admin.site.register(Movie)
admin.site.register(Showtime)
